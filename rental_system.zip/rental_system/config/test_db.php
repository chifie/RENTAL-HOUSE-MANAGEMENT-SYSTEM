<?php
require_once 'db.php';

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM admin");
    $count = $stmt->fetchColumn();
    echo "✅ Success! Connected to <b>$db</b>.<br>";
    echo "Found <b>$count</b> users in the admin table.";
} catch (Exception $e) {
    echo "❌ Database Error: " . $e->getMessage();
}
?>