<?php
/**
 * includes/auth.php
 * Updated: April 2, 2026 - Role-Based Access Control (RBAC)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. GLOBAL LOGIN CHECK
// Redirect to login if no user session exists
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

/**
 * 2. ROLE CHECKER
 * Returns true if the logged-in user is an Admin.
 */
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Admin';
}

/**
 * 3. ADMIN-ONLY RESTRICTION
 * Call this at the top of sensitive pages (e.g., delete_house.php or reports.php)
 */
function restrictToAdmin() {
    if (!isAdmin()) {
        // Redirect unauthorized staff back to dashboard with a warning
        header("Location: dashboard.php?error=unauthorized");
        exit();
    }
}

/**
 * 4. USER INFO HELPERS
 * Get the name of the person currently logged in for "Received By" fields.
 */
function getLoggedInUser() {
    return $_SESSION['username'] ?? 'System User';
}
?>