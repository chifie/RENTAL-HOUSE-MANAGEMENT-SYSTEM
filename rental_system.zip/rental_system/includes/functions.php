<?php
/**
 * includes/functions.php
 * Full Corrected Version - April 7, 2026
 * Resolves Dashboard Fatal Errors and adds Security Enhancements
 */

// --- 1. CORE UTILITIES & SECURITY ---

/**
 * Sanitizes user input to prevent XSS attacks.
 */
function clean(?string $data): string {
    return htmlspecialchars(strip_tags(trim($data ?? '')));
}

/**
 * Formats numbers into Tanzanian Shilling (Tsh) currency format.
 */
function formatMoney($amount): string {
    $val = (float)($amount ?? 0);
    return "Tsh " . number_format($val, 0, '.', ',');
}

/**
 * Handles page redirection safely.
 */
function redirect(string $url): void {
    if (!headers_sent()) {
        header("Location: $url");
        exit();
    }
    echo '<script>window.location.href="'.$url.'";</script>';
    exit();
}

// --- 2. DASHBOARD & FINANCIAL FUNCTIONS (Fixed Fatal Errors) ---

/**
 * Calculates revenue for a specific month (e.g., 'April 2026').
 * Matches your 'payments' table: amount_paid and month_for columns.
 */
function getMonthlyRevenue(PDO $pdo, string $month): float {
    $sql = "SELECT SUM(amount_paid) FROM payments WHERE month_for = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$month]);
    $result = $stmt->fetchColumn();
    return (float)($result ?? 0);
}

/**
 * Calculates the total lifetime revenue collected by the system.
 */
function getTotalRevenue(PDO $pdo): float {
    $sql = "SELECT SUM(amount_paid) FROM payments";
    $result = $pdo->query($sql)->fetchColumn();
    return (float)($result ?? 0);
}

/**
 * Calculates projected income based on houses currently marked as 'Occupied'.
 */
function getExpectedIncome(PDO $pdo): float {
    $sql = "SELECT SUM(rent_amount) FROM houses WHERE status = 'Occupied'";
    $result = $pdo->query($sql)->fetchColumn();
    return (float)($result ?? 0);
}

// --- 3. TENANT & HOUSE MANAGEMENT ---

/**
 * Fetches tenants whose next_payment_date is in the past.
 */
function getOverdueTenants(PDO $pdo): array {
    $today = date('Y-m-d');
    $sql = "SELECT t.*, t.id AS id, h.house_number 
            FROM tenants t 
            JOIN houses h ON t.house_id = h.id 
            WHERE t.next_payment_date < ? AND t.status = 'Active'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$today]);
    return $stmt->fetchAll();
}

/**
 * Fetches all tenants joined with their respective house details.
 */
function getAllTenants(PDO $pdo): array {
    $sql = "SELECT t.*, 
                   t.id AS id, 
                   h.house_number AS house_no, 
                   h.rent_amount AS price 
            FROM tenants t 
            LEFT JOIN houses h ON t.house_id = h.id 
            ORDER BY t.id DESC";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Fetches all houses currently marked as 'Available'.
 */
function getAvailableHouses(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT id, house_number, features, rent_amount FROM houses WHERE status = 'Available' ORDER BY id DESC");
    $stmt->execute();
    return $stmt->fetchAll();
}

// --- 4. SYSTEM HELPERS ---

/**
 * Generic record counter with basic table name validation.
 */
function countRecords(PDO $pdo, string $table, string $condition = ""): int {
    $allowed_tables = ['houses', 'tenants', 'payments', 'admin', 'inquiries'];
    if (!in_array($table, $allowed_tables)) return 0;
    
    $sql = "SELECT COUNT(*) FROM $table $condition";
    return (int)$pdo->query($sql)->fetchColumn();
}

/**
 * Generates HTML badges for payment status based on date proximity.
 */
function getStatusBadge(?string $expiry_date): string {
    if (!$expiry_date) return '<span class="badge bg-secondary">No Date</span>';
    
    $today = strtotime(date('Y-m-d'));
    $expiry = strtotime($expiry_date);
    $diff = ($expiry - $today) / 86400;

    if ($expiry < $today) {
        return '<span class="badge bg-danger shadow-sm">Overdue</span>';
    } elseif ($diff <= 5) {
        return '<span class="badge bg-warning text-dark shadow-sm">Due Soon</span>';
    } else {
        return '<span class="badge bg-success shadow-sm">Paid</span>';
    }
}
?>