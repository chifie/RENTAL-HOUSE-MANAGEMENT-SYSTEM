<footer class="footer mt-auto py-4 border-top bg-white d-print-none">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <span class="text-muted small text-uppercase fw-bold" style="letter-spacing: 1px;">
                        &copy; <?php echo date('Y'); ?> <span class="text-primary">RentalMS</span>
                    </span>
                    <span class="mx-2 text-light">|</span>
                    <span class="text-muted small">Modern Property Management</span>
                </div>
                <div class="col-md-6 text-center text-md-end mt-3 mt-md-0">
                    <a href="#" class="text-decoration-none text-muted me-3 small">
                        <i class="fas fa-shield-alt me-1 text-success"></i> Secure System
                    </a>
                    <a href="support.php" class="text-decoration-none text-muted small">
                        <i class="fas fa-question-circle me-1 text-info"></i> Support
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <button onclick="topFunction()" id="backToTop" class="btn btn-primary shadow-lg rounded-circle d-print-none" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://kit.fontawesome.com/your-kit-code.js" crossorigin="anonymous"></script>

    <script>
        /**
         * AUTO-HIDE ALERTS
         * Keeps the dashboard clean by removing success messages after 4 seconds.
         * Note: Red (danger) alerts stay visible so the user doesn't miss errors.
         */
        setTimeout(function() {
            let alerts = document.querySelectorAll('.alert:not(.alert-danger)'); 
            alerts.forEach(function(alert) {
                alert.style.transition = "opacity 0.5s ease";
                alert.style.opacity = "0";
                setTimeout(() => {
                    let bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 500);
            });
        }, 4000);

        /**
         * BACK TO TOP BUTTON LOGIC
         */
        let mybutton = document.getElementById("backToTop");

        window.onscroll = function() { 
            if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
                mybutton.style.display = "flex";
            } else {
                mybutton.style.display = "none";
            }
        };

        function topFunction() {
            window.scrollTo({
                top: 0, 
                behavior: 'smooth'
            });
        }
    </script>

    <style>
        /* Footer Styling */
        .footer {
            background-color: #ffffff;
            z-index: 10;
        }

        /* Floating Button Styling */
        #backToTop {
            display: none; 
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 99;
            width: 45px;
            height: 45px;
            align-items: center;
            justify-content: center;
            border: none;
            outline: none;
            transition: all 0.3s ease;
        }

        #backToTop:hover {
            transform: translateY(-5px);
            background-color: #0d6efd;
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.4) !important;
        }

        /* Ensure footer doesn't show during receipt printing */
        @media print {
            .footer, #backToTop {
                display: none !important;
            }
        }
    </style>
</body>
</html>