<div class="col-md-3 col-lg-2 d-md-block sidebar collapse p-0 shadow">
    <div class="position-sticky pt-3">
        <div class="px-3 mb-4 text-center">
            <h5 class="fw-bold text-white">RMS ADMIN</h5>
            <small class="text-white-50 d-block mb-1"><?php echo $_SESSION['full_name'] ?? 'User'; ?></small>
            <span class="badge bg-primary small"><?php echo $_SESSION['role'] ?? 'Staff'; ?></span>
            <hr class="text-secondary">
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>

            <?php if (isAdmin()): ?>
            <li class="nav-item">
                <a class="nav-link text-info" href="reports.php">
                    <i class="fas fa-chart-line me-2"></i> Financial Reports
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link" href="manage_houses.php">
                    <i class="fas fa-home me-2"></i> Manage Houses
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="tenants.php">
                    <i class="fas fa-users me-2"></i> Tenants
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="payments.php">
                    <i class="fas fa-money-bill-wave me-2"></i> Payments
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="inquiries.php">
                    <i class="fas fa-envelope me-2"></i> Inquiries 
                    <span class="badge bg-danger rounded-pill ms-auto">New</span>
                </a>
            </li>

            <li class="nav-item mt-5">
                <a class="nav-link text-warning" href="logout.php">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</div>