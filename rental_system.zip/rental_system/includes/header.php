<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RentalMS | Modern Property Management</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.min.css">

    <style>
        :root {
            --primary-color: #0d6efd;
            --sidebar-bg: #212529;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }

        /* Smooth Sidebar transitions */
        .sidebar {
            min-height: 100vh;
            background: var(--sidebar-bg);
            transition: all 0.3s;
        }

        /* Modern Card Styling */
        .card {
            border-radius: 12px;
            border: none;
            transition: transform 0.2s ease;
        }

        /* Hide Scrollbar for cleaner look but keep functionality */
        ::-webkit-scrollbar {
            width: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #ccc;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #999;
        }

        /* Print Settings for Receipts */
        @media print {
            .navbar, .sidebar, .btn-toolbar, .d-print-none {
                display: none !important;
            }
            body { background: white !important; }
            .container-fluid { padding: 0 !important; }
        }
    </style>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">